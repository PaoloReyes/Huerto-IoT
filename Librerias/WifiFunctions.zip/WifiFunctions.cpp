#include "WifiFunctions.h"

void setup_wifi(const char *ssid, const char *password) {
  delay(10);
  Serial.println();
  Serial.print("Conectando a ");
  Serial.println(ssid);
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  randomSeed(micros());
  Serial.println("");
  Serial.println("WiFi conectado");
  Serial.println("Dirección IP: ");
  Serial.println(WiFi.localIP());
}

void send_message(PubSubClient *client, const char *clientId, const char *topic, char *msg) {
  while (!client->connected()) {
    Serial.print("Intentando establecer conexión MQTT...\n");
    if (client->connect(clientId)) {
      Serial.print(clientId);
      Serial.println(": Conectado");
      Serial.print("Enviando mensaje: ");
      Serial.println(msg);
      client->publish(topic, msg);
    }
  }
}
