#ifndef WIFI_FUNCTIONS_H
  #define WIFI_FUNCTIONS_H
  #include <Arduino.h>
  #include <PubSubClient.h>
  #include <WiFi.h>
  void setup_wifi(const char *ssid, const char *password);                                                                           //Declaración de función para conectar WiFi
  void send_message(PubSubClient *client, const char *clientId, const char *topic, char *msg); //Declaración de función para conectar a mqtt
#endif 
