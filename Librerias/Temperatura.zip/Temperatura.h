/*
 * Este Header contiene las funciones necesarias para usar un termistor como divisor de voltaje
 */
#ifndef TEMPERATURA_H
  #define TEMPERATURA_H
  #include <Arduino.h>
  /*
   * Clase para crear objetos termistor
   */
  class Termistor {
    private:
      uint8_t adc_pin = 0;
      uint16_t adc_res = 0;
      float c1 = 0.001129148, c2 = 0.000234125, c3 = 0.0000000876741;
    public:
      /// @brief Configura el pin y la resistencia en serie del termistor
      Termistor(uint8_t pin, uint16_t res);
      /// @brief Devuelve la temperatura leida por el termistor
      float get_temperature();
  };
#endif
