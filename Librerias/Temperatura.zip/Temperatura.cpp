#include "temperatura.h"

Termistor::Termistor(uint8_t pin, uint16_t res) {
  this->adc_pin = pin;
  this->adc_res = res;
}

float Termistor::get_temperature() {
  int lectura = 0;
  double temp, resistance;
  lectura = map(analogRead(this->adc_pin), 0, 4095, 4095, 0);
  resistance =this->adc_res*(4095.0/(float)lectura-1.0);
  temp = (1.0/(this->c1+this->c2*log(resistance)+this->c3*log(resistance)*log(resistance)*log(resistance)));
  return temp-273.15;
}
